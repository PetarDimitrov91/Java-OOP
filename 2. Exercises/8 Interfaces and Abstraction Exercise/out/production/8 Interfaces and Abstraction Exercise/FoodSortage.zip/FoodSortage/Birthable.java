package FoodSortage;

public interface Birthable {
    String getBirthDate();
}
