package FoodSortage;

public interface Identifiable {
    String getId();
}
