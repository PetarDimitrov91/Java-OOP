package FoodSortage;

public class Main {

}
