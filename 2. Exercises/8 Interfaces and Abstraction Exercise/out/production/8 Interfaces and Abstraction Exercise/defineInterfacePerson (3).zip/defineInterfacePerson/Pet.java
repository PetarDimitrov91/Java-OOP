package defineInterfacePerson;

public class Pet implements Birthable, Name {

    private String name;
    private String birthDate;

    public Pet(String name, String birtDate) {
        this.name = name;
        this.birthDate = birtDate;
    }

    @Override
    public String getBirthDate() {
        return null;
    }

    @Override
    public String getName() {
        return name;
    }
}
