package defineInterfacePerson;

public interface Model {
    String getModel();
}
