package defineInterfacePerson;

public interface Person extends Name{

    int getAge();

}
