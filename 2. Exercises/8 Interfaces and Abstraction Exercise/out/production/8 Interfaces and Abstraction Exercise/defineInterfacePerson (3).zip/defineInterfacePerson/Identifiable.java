package defineInterfacePerson;

public interface Identifiable {
    String getId();
}
