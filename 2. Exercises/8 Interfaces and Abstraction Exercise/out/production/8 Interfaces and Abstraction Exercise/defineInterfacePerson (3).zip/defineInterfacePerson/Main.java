package defineInterfacePerson;

public class Main {

}
