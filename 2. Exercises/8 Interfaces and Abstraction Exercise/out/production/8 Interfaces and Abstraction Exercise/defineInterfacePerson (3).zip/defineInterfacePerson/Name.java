package defineInterfacePerson;

public interface Name {
    String getName();
}
