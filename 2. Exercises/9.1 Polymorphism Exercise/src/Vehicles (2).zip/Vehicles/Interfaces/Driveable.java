package Vehicles.Interfaces;

public interface Driveable {

    void drive(double kilometers);
}
