package Vehicles;

import Vehicles.entities.Car;
import Vehicles.entities.Truck;
import Vehicles.entities.Vehicle;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);

        String[] carData = console.nextLine().trim().split("\\s+");
        String[] truckData = console.nextLine().trim().split("\\s+");
        int commandsNumber = Integer.parseInt(console.nextLine());

        Vehicle car = new Car(Double.parseDouble(carData[1]), Double.parseDouble(carData[2]));
        Vehicle truck = new Truck(Double.parseDouble(truckData[1]), Double.parseDouble(truckData[2]));
        for (int i = 0; i < commandsNumber; i++) {
            String[] commandData = console.nextLine().trim().split("\\s+");

            String command = commandData[0];
            String vehicleType = commandData[1];

            switch (command) {
                case "Drive":
                    double kilometers = Double.parseDouble(commandData[2]);
                    switch (vehicleType) {
                        case "Car":
                            car.drive(kilometers);
                            break;
                        case "Truck":
                            truck.drive(kilometers);
                            break;
                    }

                    break;
                case "Refuel":
                    double liters = Double.parseDouble(commandData[2]);
                    switch (vehicleType) {
                        case "Car":
                            car.refuel(liters);
                            break;
                        case "Truck":
                            truck.refuel(liters);
                            break;
                    }
                    break;
            }
        }
        System.out.println(car);
        System.out.println(truck);
    }
}
