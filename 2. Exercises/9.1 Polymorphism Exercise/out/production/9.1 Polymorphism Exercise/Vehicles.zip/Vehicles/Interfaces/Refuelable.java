package Vehicles.Interfaces;

public interface Refuelable {
    void refuel(double liters);
}
