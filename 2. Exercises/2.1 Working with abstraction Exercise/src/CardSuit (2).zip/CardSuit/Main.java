package CardSuit;

public class Main {
    public static void main(String[] args) {
        System.out.println("Card Ranks:");
 //       CardSuit[] values = CardSuit.values();
        for (CardRanks value : CardRanks.values()) {
            System.out.printf("Ordinal value: %d; Name value: %s%n",value.ordinal(),value.toString());
        }
    }
}
