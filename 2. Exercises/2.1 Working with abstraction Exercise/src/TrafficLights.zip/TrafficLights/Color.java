package TrafficLights;

public enum Color {
    RED,
    YELLOW,
    GREEN
}
